<div class="section" style="background:black;">
            <div class="container" style="padding: 10px 0 10px 0;">
                <div class="row">
                    <div class="col-md-3 text-center">
                        <a><i class="fa fa-2x fa-fw fa-instagram fa-inverse"></i></a>
                    </div>
                    <div class="col-md-3 text-center">
                        <a><i class="fa fa-2x fa-fw fa-twitter fa-inverse"></i></a>
                    </div>
                    <div class="col-md-3 text-center">
                        <a><i class="fa fa-2x fa-fw fa-facebook fa-inverse"></i></a>
                    </div>
                    <div class="col-md-3 text-center">
                        <a><i class="fa fa-2x fa-fw fa-github fa-inverse"></i></a>
                    </div>
                </div>
            </div>
</div>
<script type="text/javascript" language="javascript" src="<?php bloginfo("template_url") ?>/app.js"></script>
<!--script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<?php /*
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
*/ ?>
</body>
</html>