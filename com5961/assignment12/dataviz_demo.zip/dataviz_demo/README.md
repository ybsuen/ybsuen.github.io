# Bootstrap Stanley Template Demo
This demonstration was prepared for an intro class to data visualization which covers data scraping (with ScrapingHub Portia), data pre-processing (with Open Refine), data aggregation (with Drupal SQL query view), and data visualization (with Bootstrap, JQuery, JQueryTable, StoryMapJS, TimelineJS, Leaflet, and C3/D3).

The demo site can be reached at this URL: http://dev-com5961a.pantheonsite.io/dataviz_demo.
