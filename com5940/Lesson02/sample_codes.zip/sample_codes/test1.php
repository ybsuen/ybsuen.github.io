<?php
$x = 2 + 5;
echo "x=".$x;
echo "<br>";
?>

<?php
if ($x == 5) {
    echo "x=5";
  } else {
    echo "Wrong. x=".$x;
  }
?>
<br>****<br>
<?php 
$i=0;
for ($i=0;$i<3;$i++) 
   {   
     echo "i=".$i."<br>"; 
   }
?>
****<br>
<?php
$i=0;
while ($i < 3):    
    echo "i=".$i."<br>";
    $i++;
endwhile
?>