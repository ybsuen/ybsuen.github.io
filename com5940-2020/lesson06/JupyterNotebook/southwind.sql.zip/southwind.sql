-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Mar 09, 2020 at 03:06 PM
-- Server version: 5.5.42
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `southwind`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` int(4) NOT NULL,
  `productCode` varchar(3) DEFAULT NULL,
  `name` varchar(9) DEFAULT NULL,
  `quantity` int(5) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `supplierID` int(3) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2050 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `productCode`, `name`, `quantity`, `price`, `supplierID`) VALUES
(1001, 'PEN', 'Pen Red', 5000, '1.23', 501),
(1002, 'XYZ', 'Pen Blue', 8000, '1.25', 503),
(1003, 'SAT', 'Pen God', 2000, '1.25', 501),
(1004, 'ABC', 'Parker Pe', 10000, '9.75', 501),
(1006, 'PEC', 'Pencil HB', 222, '123.23', 501),
(1007, 'PEN', 'Pen Red', 5000, '1.23', 501),
(1008, 'PEN', 'Pen Blue', 8000, '1.25', 501),
(1009, 'PEN', 'Pen Black', 2000, '1.25', 501),
(1010, 'PEC', 'Pencil 2B', 10000, '0.48', 501),
(1011, 'PEC', 'Pencil 2H', 8000, '0.49', 502),
(1012, 'PEC', 'Pencil HB', 0, '99999.99', 501),
(1013, 'PEN', 'Pen Red', 5000, '1.23', 501),
(1015, 'PEN', 'Green 2B', 20, '2.50', 502),
(1016, 'PEC', 'Green 2B', 43, '3.50', 501),
(2001, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2002, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2003, 'PEN', 'Pencil 5B', 100, '0.73', 503),
(2004, 'PEC', 'Pencil 6B', 500, '0.47', 502),
(2005, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2006, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2007, 'PEN', 'Pencil 5B', 100, '0.73', 503),
(2008, 'PEN', 'Pencil 6B', 500, '0.47', 502),
(2009, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2010, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2011, 'PEC', 'Pencil 5B', 100, '0.73', 503),
(2012, 'PEC', 'Pencil 6B', 500, '0.47', 502),
(2013, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2014, 'PEG', 'Pencil 4B', 200, '1.20', 502),
(2015, 'PEG', 'Pencil 5B', 100, '0.55', 501),
(2016, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2017, 'PEC', 'Pencil 5B', 100, '0.73', 503),
(2018, 'PEC', 'Pencil 6B', 500, '0.47', 502),
(2019, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2020, 'PEG', 'Pencil 4B', 200, '1.20', 502),
(2021, 'PEG', 'Pencil 5B', 100, '0.55', 501),
(2022, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2023, 'PEC', 'Pencil 5B', 100, '0.73', 503),
(2024, 'PEC', 'Pencil 6B', 500, '0.47', 502),
(2025, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2026, 'PEG', 'Pencil 4B', 200, '1.20', 502),
(2027, 'PEG', 'Pencil 5B', 100, '0.55', 501),
(2028, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2029, 'PEC', 'Pencil 5B', 100, '0.73', 503),
(2030, 'PEC', 'Pencil 6B', 500, '0.47', 502),
(2031, 'PEC', 'Pencil 3B', 500, '0.52', 503),
(2032, 'PEG', 'Pencil 4B', 200, '1.20', 502),
(2033, 'PEG', 'Pencil 5B', 100, '0.55', 501),
(2034, 'PEC', 'Pencil 4B', 200, '0.62', 501),
(2035, 'PEC', 'Pencil 5B', 100, '0.73', 503),
(2045, 'SUN', 'Parker', 5, '999.00', 502),
(2047, 'EGG', 'Bernard', 100, '1.50', 502),
(2048, 'EGG', 'Bernard', 100, '1.50', 502);

-- --------------------------------------------------------

--
-- Table structure for table `Roll-up`
--

CREATE TABLE `Roll-up` (
  `Name` varchar(8) DEFAULT NULL,
  `product_no` varchar(32) DEFAULT NULL,
  `total_items_by_category` int(1) DEFAULT NULL,
  `icon` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Roll-up`
--

INSERT INTO `Roll-up` (`Name`, `product_no`, `total_items_by_category`, `icon`) VALUES
('radio', '5, 43, 23, 34, 56, 4', 6, 'fa fa-5x fa-fw t fa-rss'),
('computer', '3, 34, 12, 5, 8, 105, 21, 3', 8, 'fa fa-5x fa-fw fa-laptop'),
('tv', '43, 12, 56, 65, 23, 4, 6, 21, 67', 9, 'fa fa-5x fa-fw fa-desktop'),
('tablet', '5, 9, 8', 3, 'fa fa-5x fa-fw fa-tablet');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplierID` int(10) unsigned NOT NULL,
  `name` varchar(30) NOT NULL DEFAULT '',
  `phone` char(8) NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=504 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplierID`, `name`, `phone`) VALUES
(501, 'ABC Traders', '88881111'),
(502, 'XYZ Company', '88882222'),
(503, 'QQ Corp', '88883333');

-- --------------------------------------------------------

--
-- Table structure for table `Venues`
--

CREATE TABLE `Venues` (
  `Name` varchar(18) DEFAULT NULL,
  `Lat` decimal(8,6) DEFAULT NULL,
  `Lng` decimal(9,6) DEFAULT NULL,
  `url` varchar(61) DEFAULT NULL,
  `Pic` varchar(245) DEFAULT NULL,
  `img_url` varchar(158) DEFAULT NULL,
  `desc` varchar(431) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Venues`
--

INSERT INTO `Venues` (`Name`, `Lat`, `Lng`, `url`, `Pic`, `img_url`, `desc`) VALUES
('North Point', '22.287111', '114.191667', 'https://en.wikipedia.org/wiki/North_Point', '"440px-Chun_Yeung_Street,_Tram_140.jpg (https://dl.airtable.com/.attachments/e685bbc78ed305ba5c19d9341209c75f/1ddc090f/440px-Chun_Yeung_Street_Tram_140.jpg)"', 'https://dl.airtable.com/.attachments/e685bbc78ed305ba5c19d9341209c75f/1ddc090f/440px-Chun_Yeung_Street_Tram_140.jpg', 'North Point is a an urban area in the Eastern District of Hong Kong. It is in the northeastern part of Hong Kong Island, between Causeway Bay and Quarry Bay, and projects toward Kowloon Bay.'),
('Mong Kok', '22.322500', '114.170556', 'https://en.wikipedia.org/wiki/Mong_Kok', '440px-Sai_Yeung_Choi_Street_South_2008_Night.jpg (https://dl.airtable.com/.attachments/7fd289e11d2242803c787d97d02a2b78/4a1b5687/440px-Sai_Yeung_Choi_Street_South_2008_Night.jpg)', 'https://dl.airtable.com/.attachments/7fd289e11d2242803c787d97d02a2b78/4a1b5687/440px-Sai_Yeung_Choi_Street_South_2008_Night.jpg', 'Mong Kok  is an area in Kowloon, Hong Kong. Mong Kok is one of the major shopping areas in Hong Kong. The area is characterised by a mixture of old and new multi-story buildings, with shops and restaurants at street level, and commercial or residential units above.'),
('Happy Valley', '22.266667', '114.183333', 'https://en.wikipedia.org/wiki/Happy_Valley,_Hong_Kong', '440px-Happy_Valley_2015.jpg (https://dl.airtable.com/.attachments/018c45cd64b25d245f641d8b4744e255/a8abdabe/440px-Happy_Valley_2015.jpg)', 'https://dl.airtable.com/.attachments/018c45cd64b25d245f641d8b4744e255/a8abdabe/440px-Happy_Valley_2015.jpg', 'Happy Valley, an upper-income residential area in Hong Kong, is home to the Happy Valley Racecourse, Hong Kong Racing Museum, Hong Kong Jockey Club Happy Valley Clubhouse, Hong Kong Sanatorium and Hospital, Hong Kong Adventist Hospital – Stubbs Road, home to a number of sports club including Valley RFC rugby club, Craigengower Cricket Club, Hong Kong FC football club, and a number of cemeteries including the Hong Kong Cemetery.'),
('Victoria Peak', '22.275469', '114.143828', 'https://en.wikipedia.org/wiki/Victoria_Peak', '400px-Victoria_Harbour.jpg (https://dl.airtable.com/.attachments/10ffd6880934beb4189ab8de7f63431e/e254a711/400px-Victoria_Harbour.jpg)', 'https://dl.airtable.com/.attachments/10ffd6880934beb4189ab8de7f63431e/e254a711/400px-Victoria_Harbour.jpg', 'Victoria Peak is a hill on the western half of Hong Kong Island. It is also known as Mount Austin, and locally as The Peak. With an elevation of 552 m (1,811 ft), it is the highest hill on Hong Kong island, ranked 31 in terms of elevation in the Hong Kong Special'),
('Lan Kwai Fong', '22.280972', '114.155528', 'https://en.wikipedia.org/wiki/Lan_Kwai_Fong', '360px-LKF_Street_View01.jpg (https://dl.airtable.com/.attachments/9efc1776d58aa8cdf92a1efd6094ed52/6ada090c/360px-LKF_Street_View01.jpg)', 'https://dl.airtable.com/.attachments/9efc1776d58aa8cdf92a1efd6094ed52/6ada090c/360px-LKF_Street_View01.jpg', 'Lan Kwai Fong (often abbreviated as LKF) is a small square of streets in Central, Hong Kong. The area was dedicated to hawkers before the Second World War, but underwent a renaissance in the mid-1980s. It is now a popular expatriate haunt in Hong Kong for drinking, clubbing and dining. The street Lan Kwai Fong is L-shaped with two ends joining with D\\''Aguilar Street.'),
('Choi Hung', '22.334484', '114.210024', 'https://en.wikipedia.org/wiki/Choi_Hung_Estate', 'choi_hung.jpeg (https://dl.airtable.com/.attachments/15dbc608cc364dd155d4500ccba5d2a2/beeb7e82/choi_hung.jpeg)', 'https://dl.airtable.com/.attachments/15dbc608cc364dd155d4500ccba5d2a2/beeb7e82/choi_hung.jpeg', 'Choi Hung Estate is a public housing estate in Ngau Chi Wan, Kowloon, Hong Kong. It was built by the former Hong Kong Housing Authority (屋宇建設委員會) and is now managed by the current Hong Kong Housing Authority (香港房屋委員會). It received a Silver Medal at the 1965 Hong Kong Institute of Architects Annual Awards.'),
('HKBU', '22.338936', '114.181953', 'https://en.wikipedia.org/wiki/Hong_Kong_Baptist_University', '2017-06-08.jpg (https://dl.airtable.com/.attachments/877503bcb4dd8d8f897c6c40c9300b5f/13854d5e/2017-06-08.jpg)', 'https://dl.airtable.com/.attachments/877503bcb4dd8d8f897c6c40c9300b5f/13854d5e/2017-06-08.jpg', 'Hong Kong Baptist University (HKBU) (Chinese: 香港浸會大學) is a publicly funded tertiary liberal arts[1] institution with a Christian education heritage. It was established as Hong Kong Baptist College with the support of American Baptists, who provided both operating and construction funds and personnel to the school in its early years. It became a public college in 1983.'),
('CUHK', '22.418498', '114.204074', 'https://en.wikipedia.org/wiki/Chinese_University_of_Hong_Kong', 'CUHK.jpeg (https://dl.airtable.com/.attachments/695430430911df5ad2577c9769c61383/8a7c0c4a/CUHK.jpeg)', 'https://dl.airtable.com/.attachments/695430430911df5ad2577c9769c61383/8a7c0c4a/CUHK.jpeg', 'The Chinese University of Hong Kong (CUHK) is a public research university in Shatin, Hong Kong formally established in 1963 by a charter granted by the Legislative Council of Hong Kong. It is the territory second oldest university and was founded as a federation of three existing colleges – Chung Chi College, New Asia College and United College – the oldest of which was founded in 1949.'),
('HKU', '22.284167', '114.137778', 'https://en.wikipedia.org/wiki/University_of_Hong_Kong', '440px-Main_Building_of_the_University_of_Hong_Kong_and_clock_tower.jpeg (https://dl.airtable.com/.attachments/f8e3c9c3ae07744c86d98f16361f7d7f/acfba70e/440px-Main_Building_of_the_University_of_Hong_Kong_and_clock_tower.jpeg)', 'https://dl.airtable.com/.attachments/f8e3c9c3ae07744c86d98f16361f7d7f/acfba70e/440px-Main_Building_of_the_University_of_Hong_Kong_and_clock_tower.jpeg', 'The University of Hong Kong (HKU) is a public research university in Hong Kong. Founded in 1911, its origins trace back to the Hong Kong College of Medicine for Chinese, which was founded in 1887. It is the oldest tertiary institution in Hong Kong.[6] Also, HKU is the first university established by the British Empire in East Asia. HKU has always been the best university in Hong Kong and one of the best universities in Asia.'),
('HK Science Musuem', '22.301000', '114.177655', 'https://en.wikipedia.org/wiki/Hong_Kong_Science_Museum', '440px-HKScienceMuseumview.jpg (https://dl.airtable.com/.attachments/22f383737e8fb434bdff596329a7016a/42678f91/440px-HKScienceMuseumview.jpg)', 'https://dl.airtable.com/.attachments/22f383737e8fb434bdff596329a7016a/42678f91/440px-HKScienceMuseumview.jpg', 'The Hong Kong Science Museum was first conceived by the Urban Council in 1976. The council hired American firm E. Verner Johnson and Associates in 1984 to help plan the museum. '),
('HK Cultural Center', '22.293850', '114.170323', 'https://en.wikipedia.org/wiki/Hong_Kong_Cultural_Centre', '480px-Hong_Kong_Cultural_Centre_201408.jpg (https://dl.airtable.com/.attachments/792c15887963b8bf9e75075b21a91d0d/dc57215f/480px-Hong_Kong_Cultural_Centre_201408.jpg)', 'https://dl.airtable.com/.attachments/792c15887963b8bf9e75075b21a91d0d/dc57215f/480px-Hong_Kong_Cultural_Centre_201408.jpg', 'The centre is located on the southwestern tip of Tsim Sha Tsui, on the former location of the Kowloon Station of the Kowloon-Canton Railway.'),
('Victoria Harbour', '22.287753', '114.173619', 'https://en.wikipedia.org/wiki/Victoria_Harbour', '"440px-Vista_del_Puerto_de_Victoria_desde_Sky100,_Hong_Kong,_2013-08-09,_DD_10.jpeg (https://dl.airtable.com/.attachments/46d727c499e74ade15065af197e45ea6/e9570ba3/440px-Vista_del_Puerto_de_Victoria_desde_Sky100_Hong_Kong_2013-08-09_DD_10.jpeg)"', 'https://dl.airtable.com/.attachments/46d727c499e74ade15065af197e45ea6/e9570ba3/440px-Vista_del_Puerto_de_Victoria_desde_Sky100_Hong_Kong_2013-08-09_DD_10.jpeg', 'Victoria Harbour is a natural landform harbour separating Hong Kong Island in the south from the Kowloon Peninsula to the north. ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplierID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2050;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplierID` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=504;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
